package dinamikverisimulasyonuodev2;

public class Node {
    int x;
    int y;

    public Node(int x,int y) {
        this.x = x;
        this.y = y;
    }
    
    
}
